/*
 * Title: Cat Database - Header File
 * Based on: Portland Community College CS 162 Computer Science II, Assignment 5
 * Author: Gabrielle Josephson
 * Date: 8/7/2020
 * Sources: C++ Programming by D.S. Malik
 */

#include <iostream>
#include <iomanip>
#include <cstring>
#include <fstream>


using namespace std;

const int MAX_STR = 100;
const double MAX_HEIGHT = 33;
const double MAX_WEIGHT = 60;
const double MIN_HEIGHT = 8;
const double MIN_WEIGHT = 2;

void toLower(char[]);

class CatBreed {
	char* breed;
	char* character;
	char* classification;
	double weight;
	double height;
	char* country;
public:
	CatBreed();
	CatBreed(char[], char[], char[], double, double, char[]);
	const char* getBreed();
	const char* getCharacter();
	const char* getClassification();
	double getWeight();
	double getHeight();
	const char* getCountry();
	CatBreed& operator= (CatBreed& otherBreed);
	~CatBreed();
};

struct node {
	CatBreed breed;
	node* next = nullptr;
};

class CatTypes {
	node* head;
	int count;
	char fileName[MAX_STR];
public:
	CatTypes();
	int addBreed();
	int loadBreeds();
	void listBreeds();
	bool removeBreed(char[]);
	bool searchBreeds(char[]);
	void writeBreeds();
	const char* getFileName();
	~CatTypes();
};

