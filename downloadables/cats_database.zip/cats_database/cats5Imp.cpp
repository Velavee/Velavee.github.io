/*
 * Title: Cat Database - Implementation File
 * Based on: Portland Community College CS 162 Computer Science II, Assignment 5
 * Author: Gabrielle Josephson
 * Date: 8/7/2020
 * Sources: C++ Programming by D.S. Malik
 */

#include "cats5Header.h"

//#pragma warning(disable:4996)

 /*
  * Converts a cstring with uppercase characters to the equivalent cstring
  * with all lowercase characters.
  * @param: lowerMe[]
  * @return: lowerMe[] by reference
  */
void toLower(char lowerMe[]) {
	int length = strlen(lowerMe);

	for (int i = 0; i < length; i++) {
		if (lowerMe[i] <= 90 && lowerMe[i] >= 65) {
			lowerMe[i] = lowerMe[i] + 32;
		}
	}
}

/*
  * CatBreed default constructor. Initializes pointer members to nullptr and double members
  * to 0.
  * @param: none
  * @return: none
 */
CatBreed::CatBreed() {
	breed = nullptr;
	character = nullptr;
	classification = nullptr;
	weight = 0;
	height = 0;
	country = nullptr;
}

/*
  * CatBreed constructor. Sets member values to user-specified inputs.
  * @param: tBreed, tCharacter, tClass, tWeight, tHeight, tCountry
  * @return: none
 */
CatBreed::CatBreed(char tBreed[], char tCharacter[], char tClass[], double tWeight, double tHeight,
	char tCountry[]) {
	int len;

	len = strlen(tBreed);
	breed = new char[len + 1];		// Allocate only as many characters are int he word plus null terminating character
	strcpy(breed, tBreed);

	len = strlen(tCharacter);
	character = new char[len + 1];
	strcpy(character, tCharacter);

	len = strlen(tClass);
	classification = new char[len + 1];
	strcpy(classification, tClass);

	weight = tWeight;
	height = tHeight;

	len = strlen(tCountry);
	country = new char[len + 1];
	strcpy(country, tCountry);
}

/*
  * CatBreed breed getter.
  * @param: none
  * @return: breed
 */
const char* CatBreed::getBreed() {
	return breed;
}

/*
  * CatBreed character getter.
  * @param: none
  * @return: character
 */
const char* CatBreed::getCharacter() {
	return character;
}

/*
  * CatBreed classification getter.
  * @param: none
  * @return: classification
 */
const char* CatBreed::getClassification() {
	return classification;
}

/*
  * CatBreed weight getter.
  * @param: none
  * @return: weight
 */
double CatBreed::getWeight() {
	return weight;
}

/*
  * CatBreed height getter.
  * @param: none
  * @return: height
 */
double CatBreed::getHeight() {
	return height;
}

/*
  * CatBreed country getter.
  * @param: none
  * @return: country
 */
const char* CatBreed::getCountry() {
	return country;
}

/*
  * CatBreed assignment operator overload function. Ensures deep copy of CatBreed object.
  * @param: otherBreed
  * @return: this
 */
CatBreed& CatBreed::operator=(CatBreed& otherBreed)
{
	if (this != &otherBreed) {								// Prevent self-assignment
		breed = new char[strlen(otherBreed.breed) + 1];		// Dynamic allocation for strings
		strcpy(breed, otherBreed.breed);

		character = new char[strlen(otherBreed.character) + 1];
		strcpy(character, otherBreed.character);

		classification = new char[strlen(otherBreed.classification) + 1];
		strcpy(classification, otherBreed.classification);

		weight = otherBreed.weight;
		height = otherBreed.height;

		country = new char[strlen(otherBreed.country) + 1];
		strcpy(country, otherBreed.country);
	}

	return *this;
}

/*
  * CatBreed destructor. Deallocates memory for dynamically allocated c-string members.
  * @param: none
  * @return: none
 */
CatBreed::~CatBreed() {
	if (breed != nullptr) {
		delete[] breed;
	}

	if (character != nullptr) {
		delete[] character;
	}

	if (classification != nullptr) {
		delete[] classification;
	}

	if (country != nullptr) {
		delete[] country;
	}
}

/*
  * CatTypes default constructor; initializes count to 0 and head to nullptr.
  * @param: none
  * @return: modifies CatTypes object
 */
CatTypes::CatTypes() {
	count = 0;
	head = nullptr;
}

/*
  * CatTypes destructor. Deallocates memory in linked list.
  * @param: none
  * @return: modifies CatTypes object
 */
CatTypes::~CatTypes() {
	node* cur;
	node* prev;

	cur = head;
	while (cur != nullptr) {
		prev = cur;
		cur = cur->next;
		delete prev;
	}
	cur = nullptr;
	prev = nullptr;
}

/*
  * Allows user to input a new data entry. User specifies the breed and all of
  * its traits through input in the console. The new entry is saved to the linked list
  * alphabetically.
  * @param: none
  * @return: modifies CatTypes object
 */
int CatTypes::addBreed() {
	char tBreed[MAX_STR];
	char tCharacter[MAX_STR];
	char tClass[MAX_STR];
	double tWeight;
	double tHeight;
	char tCountry[MAX_STR];
	node* temp;
	node* cur = head;

	cin.clear();
	cin.ignore(MAX_STR, '\n');

	cout << "\nWhat is the name of the cat breed? ";
	cin.getline(tBreed, MAX_STR);
	toLower(tBreed);

	cout << "What are the characterisitcs? ";
	cin.getline(tCharacter, MAX_STR);
	toLower(tCharacter);

	cout << "What is the classification? ";
	cin.getline(tClass, MAX_STR);
	toLower(tClass);

	cout << "What is the average weight (between 2 and 60 pounds)? ";
	cin >> tWeight;
	while (tWeight > MAX_WEIGHT || tWeight < MIN_WEIGHT || cin.fail()) {
		if (cin.fail()) {
			cin.clear();
			cin.ignore(MAX_STR, '\n');
		}
		cout << "Error, please enter positive values between 2 and 60" << endl;
		cout << "What is the average weight (between 2 and 60 pounds)? ";
		cin >> tWeight;
	}

	cout << "What is the average height(between 8 and 33 inches)? ";
	cin >> tHeight;
	while (tHeight > MAX_HEIGHT || tHeight < MIN_HEIGHT || cin.fail()) {
		if (cin.fail()) {
			cin.clear();
			cin.ignore(MAX_STR, '\n');
		}
		cout << "Error, please enter positive values between 8 and 33." << endl;
		cout << "What is the average height(between 8 and 33 inches)? ";
		cin >> tHeight;
	}

	cin.ignore(MAX_STR, '\n');

	cout << "What is the country of origin? ";
	cin.getline(tCountry, MAX_STR);

	cin.clear();

	CatBreed newBreed(tBreed, tCharacter, tClass, tWeight,
		tHeight, tCountry);

	temp = new node;			// New data entry is in temp so that we can point a node in linked list to it
	temp->breed = newBreed;
	cur = head;

	if (head == nullptr) {		// Case for when linked list is empty
		head = temp;
		head->next = nullptr;
		cur = head;
	}
	else if (strcmp(temp->breed.getBreed(), head->breed.getBreed()) <= 0) {	// Case for when entry comes alphabetically before head entry
		temp->next = head;
		head = temp;			// Temp becomes new head and temp->next points to old head
		cur = head;
	}
	else {						// Case for when new entry alphabetically belongs somewhere after head entry
		cur = head;
		while (cur->next != nullptr) {
			if (strcmp(cur->next->breed.getBreed(), temp->breed.getBreed()) >= 0) {
				break;
			}
			else {
				cur = cur->next;
			}
		}
		temp->next = cur->next;
		cur->next = temp;
		cur = cur->next;
	}

	temp = nullptr;

	cout << "\n" << cur->breed.getBreed() << " was successfully added to the database." << endl;

	count++;
	return count;		// Return number of breeds now in memory

}


/*
  * Loads breeds from an input file specified by the user. All data is saved to memory to be used
  * by other functions.
  * @param: none
  * @return: modifies CatTypes object
 */
int CatTypes::loadBreeds() {

	ifstream inFile;
	char tempBreed[MAX_STR];
	char tempCharacter[MAX_STR];
	char tempGroup[MAX_STR];
	double tempWeight;
	double tempHeight;
	char tempCountry[MAX_STR];
	node * cur;
	node* temp;

	do {
		cout << "What is the name of the name of the cat breed data file? ";
		cin.getline(fileName, MAX_STR);

		if (strcmp(fileName, "quit") == 0 || strcmp(fileName, "q") == 0 || strcmp(fileName, "Q") == 0) {
			return -1;
		}

		inFile.open(fileName);
		if (!inFile) {
			cout << fileName << " was not found. Try again or type 'quit' to exit the program." << endl;
		}
	} while (!inFile);

	if (inFile.peek() == inFile.eof()) {
		return 0;
	}
	else {
		while (!inFile.eof()) {
			inFile.getline(tempBreed, MAX_STR, ',');
			toLower(tempBreed);
			inFile.getline(tempCharacter, MAX_STR, ',');
			toLower(tempCharacter);
			inFile.getline(tempGroup, MAX_STR, ',');
			toLower(tempGroup);
			inFile >> tempWeight;
			inFile.ignore();
			inFile >> tempHeight;
			inFile.ignore();
			inFile.getline(tempCountry, MAX_STR);

			CatBreed newBreed(tempBreed, tempCharacter, tempGroup, tempWeight,
				tempHeight, tempCountry);

			temp = new node;			// New data entry is in temp so that we can point a node in linked list to it
			temp->breed = newBreed;
			cur = head;

			if (head == nullptr) {		// Case for when linked list is empty
				head = temp;
				head->next = nullptr;
				cur = head;
			}
			else if (strcmp(temp->breed.getBreed(), head->breed.getBreed()) <= 0) {		// Case for when entry comes alphabetically before head entry
				temp->next = head;
				head = temp;			// Temp becomes new head and temp->next points to old head
				cur = head;
			}
			else {						// Case for when new entry alphabetically belongs somewhere after head entry
				cur = head;
				while (cur->next != nullptr) {
					if (strcmp(cur->next->breed.getBreed(), temp->breed.getBreed()) >= 0) {
						break;
					}
					else {
						cur = cur->next;
					}
				}
				temp->next = cur->next;
				cur->next = temp;
				cur = cur->next;
			}

			temp = nullptr;
			count++;

			inFile.peek();
		}

		inFile.close();

		return count;		// Return number of breeds now in memory
	}

}

/*
  * Prints data saved in memory to the console.
  * @param: none
  * @return: none
 */
void CatTypes::listBreeds() {
	node* cur;

	if (head == nullptr) {
		return;
	}
	else {
		cout << left;		// Print data field headers to the console
		cout << setw(23) << "\nName" << setw(35) << "Description" << setw(18) << "Group" << setw(16) << "Weight" << setw(16) << "Height" << setw(17) << "Origin" << endl;
		cout << "------------------------------------------------------------------------------------------------------------------" << endl;

		cur = head;

		while (cur != nullptr) {		// Print data to the console under appropriate headers
			cout << setw(23) << cur->breed.getBreed() << setw(35) << cur->breed.getCharacter() << setw(18) << cur->breed.getClassification() << setw(16) << fixed << showpoint << setprecision(2) << cur->breed.getWeight() <<
				setw(16) << cur->breed.getHeight() << setw(17) << cur->breed.getCountry() << endl;
			cur = cur->next;
		}
	}
}

/*
  * Allows user to select a breed entry to delete from memory. If the user attempts to delete an entry that does
  * not exist, no changes will be made.
  * @param: none
  * @return: modifies CatTypes object
 */
bool CatTypes::removeBreed(char toDelete[])
{
	bool found = false;
	node* cur = head;
	node* prev = head;

	while (cur != nullptr) {	// Find data entry in memory
		if (strcmp(cur->breed.getBreed(), toDelete) == 0) {
			found = true;
			break;
		}
		else {
			prev = cur;
			cur = cur->next;
		}
	}

	if (found == true) {		// If data entry exists, delete the entry
		if (cur == head) {
			head = head->next;
			delete cur;
		}
		else {
			prev->next = cur->next;
			delete cur;
		}
		count--;
		return true;
	}
	else {						// If the data entry does not, function returns false
		return false;
	}
}

/*
  * Allows user to search for a breed entry that has been saved in memory. If the entry is found, its details
  * will be printed to the console.
  * @param: none
  * @return: none
 */
bool CatTypes::searchBreeds(char searchWord[]) {

	node* cur = head;


	while (cur != nullptr) {			// Search for data entry
		if (strcmp(searchWord, cur->breed.getBreed()) == 0) {
			cout << "\nInformation on " << cur->breed.getBreed() << " is as follows: " << endl;
			cout << cur->breed.getCharacter() << ", " << cur->breed.getClassification() << ", average weight: " << cur->breed.getWeight() << " pounds, average height: " <<
				cur->breed.getHeight() << " inches, from " << cur->breed.getCountry() << endl;
			return 1;
		}
		else {
			cur = cur->next;
		}
	}
	return 0;		// If data entry is not found, function returns false
}

/*
  * Writes data that is saved in memory to the same file that was initially used to load the data. Each entry is a
  * line in the output file. Categories within one entry are separted by a comma (,).
  * @param: none
  * @return: output file is modified
 */
void CatTypes::writeBreeds() {
	ofstream outFile;
	node* cur = head;

	outFile.open(fileName);		// Open same file used for input
	if (!outFile) {
		cout << "Error writing data to output file." << endl;
		return;
	}

	while (cur != nullptr) {		// Print contents of linked list to output file
		outFile << cur->breed.getBreed() << "," << cur->breed.getCharacter() << "," << cur->breed.getClassification() << "," << fixed << showpoint << setprecision(2) << cur->breed.getWeight() <<
			"," << cur->breed.getHeight() << "," << cur->breed.getCountry() << endl;
		cur = cur->next;
	}

	outFile.close();
}

/*
  * CatTypes fileName getter.
  * @param: none
  * @return: fileName
 */
const char* CatTypes::getFileName()
{
	return fileName;
}
